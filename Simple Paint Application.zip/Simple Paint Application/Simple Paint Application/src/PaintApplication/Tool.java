package PaintApplication;

public enum Tool {
    FREE_HAND,
    ERASER,
    RECTANGLE,
    OVAL,
    LINE
}